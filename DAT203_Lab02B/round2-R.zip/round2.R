round2<-function(x) {
  # takes in a value and rounds it to 2 decimal places
  round(x,2)
}